import streamlit as st
from bot.query_engine import ask_bot
from bot.llm_answer import summarize_result

st.set_page_config(page_title="DevOps Knowledge Assistant", page_icon="🤖")
st.title("🤖 DevOps Knowledge Assistant")

query = st.text_input("💬 Hỏi tôi về pipeline, Jira, CI/CD...")

if query:
    with st.spinner("🔍 Đang tìm câu trả lời..."):
        result = ask_bot(query)
        summary = summarize_result(result, query)
        st.markdown("### 🧠 Trả lời bằng LLM")
        st.write(summary)

        st.markdown("---")
        st.markdown("### 📄 Dữ liệu thô")
        st.json(result)
