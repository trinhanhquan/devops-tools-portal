from neo4j import GraphDatabase
import os

NEO4J_URL = os.getenv("NEO4J_URL", "bolt://localhost:7687")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "test")

driver = GraphDatabase.driver(NEO4J_URL, auth=(NEO4J_USER, NEO4J_PASSWORD))

def create_issue_node(tx, doc):
    tx.run(
        """
        MERGE (i:Issue {id: $id})
        SET i.text = $text
        MERGE (p:Project {name: $project})
        MERGE (s:Status {name: $status})
        MERGE (t:IssueType {name: $issuetype})
        MERGE (i)-[:BELONGS_TO]->(p)
        MERGE (i)-[:HAS_STATUS]->(s)
        MERGE (i)-[:HAS_TYPE]->(t)
        """,
        id=doc["id"],
        text=doc["text"],
        project=doc["metadata"]["project"],
        status=doc["metadata"]["status"],
        issuetype=doc["metadata"]["issuetype"]
    )

def update_issues_graph(docs):
    with driver.session() as session:
        for doc in docs:
            session.write_transaction(create_issue_node, doc)

    print(f"✅ Pushed {len(docs)} issues to Neo4j graph")
