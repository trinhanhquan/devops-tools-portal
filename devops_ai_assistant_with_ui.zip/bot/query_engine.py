import os
from langchain_community.embeddings import OllamaEmbeddings
from langchain.vectorstores import FAISS
from neo4j import GraphDatabase

# === Vector DB ===
VECTOR_DIR = "vector_store/faiss_index"

def search_vector_store(query, top_k=5, model_name="nomic-embed-text"):
    embeddings = OllamaEmbeddings(model=model_name)
    db = FAISS.load_local(VECTOR_DIR, embeddings, allow_dangerous_deserialization=True)
    results = db.similarity_search(query, k=top_k)
    return results

# === Neo4j ===
NEO4J_URL = os.getenv("NEO4J_URL", "bolt://localhost:7687")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "test")

neo4j_driver = GraphDatabase.driver(NEO4J_URL, auth=(NEO4J_USER, NEO4J_PASSWORD))

def query_graph(cypher_query):
    with neo4j_driver.session() as session:
        result = session.run(cypher_query)
        return [dict(record) for record in result]

# === Simple Router ===
def ask_bot(user_query):
    if "status" in user_query.lower():
        print("🤖 Routing to Neo4j for status...")
        cypher = (
            "MATCH (i:Issue)-[:HAS_STATUS]->(s:Status) "
            "RETURN i.id AS id, s.name AS status "
            "LIMIT 10"
        )
        return query_graph(cypher)
    else:
        print("🤖 Routing to Vector DB for similarity search...")
        return search_vector_store(user_query)
