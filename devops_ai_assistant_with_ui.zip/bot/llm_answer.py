def summarize_result(result_list, question, model="ollama"):
    if model == "ollama":
        from langchain_community.llms import Ollama
        llm = Ollama(model="llama3")
    else:
        from langchain.chat_models import ChatOpenAI
        llm = ChatOpenAI()

    prompt = f"""
    Dựa trên dữ liệu sau, hãy trả lời câu hỏi sau bằng tiếng Việt ngắn gọn:
    Câu hỏi: {question}
    Dữ liệu: {result_list}
    """

    return llm.invoke(prompt)
