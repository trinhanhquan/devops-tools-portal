
import streamlit as st
from bot.query_engine import ask_bot

st.title("🧠 DevOps Assistant Bot")

user_input = st.text_input("Ask your question:")

if user_input:
    st.markdown("### ⏳ Bot is thinking...")
    response = ask_bot(user_input)

    if isinstance(response, dict) and "result" in response and "debug" in response:
        st.markdown("### 🤖 Result")
        st.write(response["result"])

        st.markdown("### 🛠 Debug Info")
        st.code(response["debug"], language='text')
    else:
        st.markdown("### 🤖 Result")
        st.write(response)
