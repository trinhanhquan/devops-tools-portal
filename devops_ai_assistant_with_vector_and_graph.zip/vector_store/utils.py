import os
from langchain_community.embeddings import OllamaEmbeddings
from langchain.vectorstores import FAISS
from langchain.docstore.document import Document

VECTOR_DIR = "vector_store/faiss_index"

def get_embeddings(model_name="nomic-embed-text"):
    return OllamaEmbeddings(model=model_name)

def prepare_documents(docs):
    return [
        Document(page_content=doc["text"], metadata=doc["metadata"])
        for doc in docs
    ]

def build_vector_store(docs, model_name="nomic-embed-text"):
    embeddings = get_embeddings(model_name)
    documents = prepare_documents(docs)
    db = FAISS.from_documents(documents, embeddings)
    db.save_local(VECTOR_DIR)
    print(f"✅ Vector store saved to {VECTOR_DIR}")
    return db

def upsert_documents(docs, model_name="nomic-embed-text"):
    if not os.path.exists(VECTOR_DIR):
        print("📁 Vector DB does not exist. Creating new one...")
        return build_vector_store(docs, model_name)

    embeddings = get_embeddings(model_name)
    db = FAISS.load_local(VECTOR_DIR, embeddings, allow_dangerous_deserialization=True)
    documents = prepare_documents(docs)
    db.add_documents(documents)
    db.save_local(VECTOR_DIR)
    print(f"🔄 Appended {len(documents)} docs to vector store.")


def search_vector_store(query, model_name="nomic-embed-text", top_k=5):
    embeddings = get_embeddings(model_name)
    db = FAISS.load_local(VECTOR_DIR, embeddings, allow_dangerous_deserialization=True)
    results = db.similarity_search(query, k=top_k)
    return [r.page_content for r in results]
