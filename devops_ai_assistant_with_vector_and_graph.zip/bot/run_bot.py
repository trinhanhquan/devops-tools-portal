import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from bot.query_engine import ask_bot

print("🤖 DevOps Assistant is ready. Ask me anything! (type 'exit' to quit)")

while True:
    q = input("\n🔎 Ask: ")
    if q.strip().lower() in ["exit", "quit"]:
        break

    result = ask_bot(q)
    if isinstance(result, list):
        for i, item in enumerate(result, 1):
            print(f"👉 [{i}] {item}")
    else:
        print("👉", result)
