import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import os
import sys

import requests
from dotenv import load_dotenv
from vector_store.utils import upsert_documents
from knowledge_graph.update_graph import update_issues_graph

# Load .env file for Jira credentials
load_dotenv()

JIRA_BASE_URL = os.getenv("JIRA_BASE_URL")
JIRA_EMAIL = os.getenv("JIRA_EMAIL")
JIRA_API_TOKEN = os.getenv("JIRA_API_TOKEN")

HEADERS = {
    "Accept": "application/json"
}

AUTH = (JIRA_EMAIL, JIRA_API_TOKEN)

def fetch_issues(project_key, max_results=50):
    url = f"{JIRA_BASE_URL}/rest/api/3/search"
    params = {
        "jql": f"project={project_key} ORDER BY created DESC",
        "maxResults": max_results,
        "fields": "summary,description,issuetype,status,project"
    }

    print(f"📡 Fetching issues from {project_key}...")
    response = requests.get(url, headers=HEADERS, auth=AUTH, params=params)
    if response.status_code != 200:
        print("❌ Failed to fetch from Jira:", response.text)
        return []

    data = response.json()
    return data.get("issues", [])

def transform_for_vector(issue):
    key = issue["key"]
    fields = issue["fields"]
    description = fields.get('description', '')
    if isinstance(description, dict):
        description = str(description)

    text = f"{fields['summary']}\n{description}"
    return {
        "id": key,
        "text": text,
        "metadata": {
            "issuetype": fields['issuetype']['name'],
            "status": fields['status']['name'],
            "project": fields['project']['key']
        }
    }

def main():
    project_key = input("Enter Jira project key (e.g., DEVOPS): ").strip().upper()

    issues = fetch_issues(project_key)
    if not issues:
        print("⚠️  No issues found or error occurred.")
        return

    print(f"✅ Fetched {len(issues)} issues.")
    docs = [transform_for_vector(issue) for issue in issues]

    for doc in docs[:3]:
        print(f"🔍 {doc['id']} → {doc['text'][:80]}...")

    upsert_documents(docs, model_name="nomic-embed-text")
    update_issues_graph(docs)

if __name__ == "__main__":
    main()
