from neo4j import GraphDatabase

NEO4J_URI = "bolt://172.29.227.59:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "testtesttest"

driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))

def query_graph(cypher_query: str):
    with driver.session() as session:
        result = session.run(cypher_query)
        return [record.data() for record in result]
