
from langchain.llms import Ollama

def generate_cypher_from_question(question: str, schema: str = None) -> str:
    """
    Uses LLaMA3 via Ollama to convert a natural language question into a Cypher query.

    Args:
        question (str): The user's natural language question.
        schema (str): Optional graph schema to guide LLM.

    Returns:
        str: Generated Cypher query as string.
    """
    default_schema = """
(:Issue)-[:HAS_STATUS]->(:Status)
(:Issue)-[:ASSIGNED_TO]->(:User)
(:Issue)-[:BELONGS_TO]->(:Project)
(:Issue)-[:HAS_LABEL]->(:Label)
    """

    schema = schema or default_schema

    prompt = f"""
You are a technical assistant. Below is a Neo4j graph schema:

{schema}

Translate the following question into a Cypher query:

Question: "{question}"
Cypher:
    """

    try:
        llm = Ollama(base_url="http://172.29.227.59:11434", model="llama3", base_url="http://localhost:11434")
        cypher_code = llm.invoke(prompt)
        return cypher_code.strip()
    except Exception as e:
        return f"Error generating Cypher: {e}"
